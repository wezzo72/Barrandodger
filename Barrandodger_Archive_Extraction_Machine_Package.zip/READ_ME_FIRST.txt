BARRANDODGER ARCHIVE EXTRACTION MACHINE

Recommended: upload Barrandodger_Archive_Extraction_Machine.ipynb to Google Colab at https://colab.research.google.com/ . Run the code cell and authorize Google Drive. It downloads public PDFs, extracts embedded text, OCRs low-text pages when possible, and produces ZIP bundles with text and page markers. Run the cell repeatedly until all PDFs are processed. Upload bundles to ChatGPT for content review.

No GitHub connector, no paid AI API, no repository modifications. Internet/API limits, very large files, encrypted PDFs, or OCR setup failures may affect individual files; check extraction_manifest.csv.
