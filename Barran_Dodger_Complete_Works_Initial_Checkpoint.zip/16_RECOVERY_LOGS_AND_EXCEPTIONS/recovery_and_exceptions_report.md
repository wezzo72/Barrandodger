# Recovery and Exceptions Report — Initial Checkpoint

**Generated:** 26 October 2026  
**Scope:** First tangible milestone; public discovery leads and initial populated register.  
**Status:** IN PROGRESS — not a complete recovery.

## Actual outputs created
- Populated discovery register: 23 records, stable IDs BDW-000001 through BDW-000023.
- Human-readable HTML catalogue with client-side search.
- PDF inventory CSV header created; no PDF file-level records are claimed yet because no PDFs were downloaded and inspected in this run.
- Preservation directory structure created locally.

## Sources and evidence observed
- Public GitHub repository search result for `wezzo72/Barrandodger` was surfaced by web search, including repository text describing a forensic dossier PDF and a legal brief PDF link.
- Public source URLs have been recorded as discovery leads. This does not establish that each link currently resolves or that its contents were inspected.
- Other public archive and publishing URLs were supplied in the task and entered as candidate source locations.

## Precise blockers
1. **Google Drive:** No authorised Google Drive connector was available in the connected tools list for this run. A Drive URL or file ID does not grant access. Connect an authorised Drive integration with read access for source discovery and write access only if later exporting.
2. **GitHub bulk collection:** No dedicated GitHub file-download/commit connector was available in this session. Public web search exposed some repository content, but it is not equivalent to recursive tree enumeration or downloading every file. A GitHub connector can be installed/authorised, or the repository ZIPs can be supplied/uploaded for processing.
3. **Network download:** The local execution environment could not resolve external hosts during a direct download attempt. Therefore no remote PDF is claimed as downloaded.
4. **Website editing:** No authenticated editor for `barran-dodgers-holy-reckoning.grok.me` was available. No live website changes were made.
5. **PDF validation / checksums:** No original PDF bytes were obtained in this run; no page counts, sizes, open tests, or SHA-256 values are asserted.
6. **Deduplication:** Titles are discovery records only. Distinct intellectual work count, edition count, exact-duplicate count, and verified PDF count remain unknown.
7. **Commercial readiness:** All candidates remain subject to provenance, completeness, third-party material, privacy/confidentiality, and rights review.

## Initial record classification
The register contains 23 discovery records. It includes authored-work candidates and separately labelled official/correspondence records that should not be counted as distinct authored works. Accordingly, 23 is **not** a verified count of authored works.

## Next concrete execution step
Connect an authorised GitHub integration or provide downloadable repository ZIPs and an authorised Google Drive connector. Then process the actual files in batches, append file-level PDF records, calculate checksums, extract text/OCR where needed, reconcile editions, and rebuild the package. Preserve originals and do not overwrite existing files.
