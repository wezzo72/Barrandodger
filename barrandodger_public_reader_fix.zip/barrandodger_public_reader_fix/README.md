# Barrandodger public archive reader workflow

This GitHub Actions workflow creates a PDF index, extracts searchable text, and calculates SHA-256 hashes whenever PDFs change on `main` (or when manually run). It uploads the generated reader as a GitHub Actions artifact retained for 90 days.

## Install
Copy `.github/workflows/public-archive-reader.yml` into the same path in `wezzo72/Barrandodger` and commit it. Then open the repository's **Actions** tab and run **Build public archive reading index** once, or add/change a PDF to trigger it.

## Important limits
- This does not change ChatGPT's browsing restrictions or grant ChatGPT repository access.
- The generated index is an Actions artifact, not a permanently hosted public website.
- SHA-256 is a content-integrity digest, not proof of authorship or date.
- This does not create an OpenTimestamps or blockchain proof.
