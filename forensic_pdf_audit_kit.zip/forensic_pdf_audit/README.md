# The Witness Remains — Forensic PDF Audit Kit

This kit creates a repeatable, page-by-page PDF extraction and review pack for the selected documents in the public `wezzo72/Barrandodger` GitHub repository.

## What it does

- Finds each requested PDF by exact filename in the repository tree (does not silently substitute another file).
- Downloads matched PDFs and records the repository path, GitHub blob SHA, file size and SHA-256 hash of the downloaded bytes.
- Extracts text page by page and uses Tesseract OCR as a fallback for pages with very little embedded text.
- Optionally performs literal quotation matching for any quotations entered in the review ledgers; a text match is only a locator, not contextual verification.
- Creates one text file per page, a combined page-text file, a CSV review ledger for every page, a document status report, and a machine-readable JSON manifest.
- Flags missing or ambiguous filenames rather than pretending those documents were examined.
- Runs on GitHub Actions and stores the output as a downloadable workflow artifact for 30 days.

## What it does not do

It does **not** prove a document's authorship, truth, legal effect, or the correctness of any article conclusion. It does **not** automatically certify quotations. OCR may misread names, dates, reference numbers and legal wording. The reviewer must compare each proposed quotation with the original PDF page image and record the outcome in the review ledger.

## Install into the repository (iPhone-friendly route)

1. Download and unzip this kit.
2. Open `https://github.com/wezzo72/Barrandodger` in Safari and sign in.
3. Add the file `.github/workflows/forensic-pdf-audit.yml` at that exact path. If the `.github/workflows` folders do not exist, create them through **Add file → Create new file** and type the full path as the filename.
4. Add `scripts/pdf_audit.py` at that exact path.
5. Add `docs/target_documents.csv` at that exact path.
6. Add `scripts/verify_quotes.py` at that exact path too. This optional checker tests any quotations you enter in the page review CSVs against extracted page text.
7. Commit each file to the `main` branch. The workflow will run when these files are committed, or you can open **Actions → Forensic PDF audit (page extraction + verification pack) → Run workflow**.
8. When it finishes, open the run and download the artifact named `forensic-pdf-audit-...`.
9. Start with `README_AUDIT_RESULTS.md` and `document_status.csv`. Open the `pages` folder and review the page text and CSV ledgers. For any quote you plan to publish, compare the extracted text to the PDF page image.

## Important operational notes

- This workflow reads the public repository and does not change or overwrite the original evidence PDFs.
- It creates a report artifact only; it does not commit generated output back into your evidence repository.
- If GitHub Actions are disabled or a file is absent, the run will show an error/status rather than claiming success.
- The manifest starts with 36 named targets listed in the current draft. Add more rows to `docs/target_documents.csv` to include further documents. Exact filenames are matched case-sensitively by repository path/basename as provided by the GitHub tree.
- If the repository branch is not `main`, change `REPO_BRANCH` in the workflow.
- The workflow requires GitHub Actions to be available for the repository/account.

## Page-level quotation verification procedure

For each quotation used in the feature:

1. Find the source document and exact page number in the generated page review CSV.
2. Copy the proposed quotation into `quote_to_verify` and the article proposition into `article_claim_to_verify`.
3. Open the source PDF and visually compare punctuation, spelling, dates, names, omissions and surrounding context.
4. Optionally run `python scripts/verify_quotes.py` to get a literal-match report. Then set `verification_status` to one of: `VERIFIED_EXACT`, `VERIFIED_WITH_ELLIPSIS`, `PARAPHRASE_CHECKED`, `OCR_CORRECTION_REQUIRED`, `NOT_FOUND`, or `CONTEXT_REQUIRED`.
5. Record reviewer notes and any limitations.
6. For conclusions, record the premises and all source pages relied upon; distinguish direct statement from inference. A conclusion is not “verified” just because a text search found a similar phrase.

## Confidence categories for the article

- A — established fact, within the scope of the source or authoritative finding.
- B — corroborated by genuinely independent sources.
- C — documented allegation, not independently established.
- D — inference, with reasoning and alternatives stated.
- E — speculation; do not present as fact.

The categories are editorial aids, not legal standards of proof.
