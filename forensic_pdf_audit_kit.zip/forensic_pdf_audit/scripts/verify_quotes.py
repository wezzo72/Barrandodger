#!/usr/bin/env python3
"""Check entered article quotations against extracted page text (literal matching only)."""
import csv, re, sys
from pathlib import Path

ROOT = Path('forensic-audit-output')

def norm(s):
    return re.sub(r'\s+', ' ', (s or '')).strip()

def main():
    ledgers = sorted((ROOT/'pages').glob('*_page_review.csv'))
    if not ledgers:
        print('No page review CSV ledgers found under forensic-audit-output/pages/.')
        return 2
    results=[]
    for ledger in ledgers:
        with ledger.open(newline='',encoding='utf-8') as f:
            reader=csv.DictReader(f)
            for row in reader:
                quote=(row.get('quote_to_verify') or '').strip()
                if not quote:
                    continue
                p=Path(row.get('page_text_file',''))
                text=p.read_text(encoding='utf-8',errors='replace') if p.exists() else ''
                qn,tn=norm(quote),norm(text)
                if qn and qn in tn:
                    status='EXACT_TEXT_MATCH_REVIEW_CONTEXT'
                else:
                    status='NO_LITERAL_MATCH_CHECK_PDF_OCR_OR_PAGE'
                results.append({
                    'source_filename':row.get('source_filename',''),
                    'repository_path':row.get('repository_path',''),
                    'page_number_1_based':row.get('page_number_1_based',''),
                    'quote_to_verify':quote,
                    'article_claim_to_verify':row.get('article_claim_to_verify',''),
                    'automated_result':status,
                    'page_text_file':str(p),
                    'reviewer_notes':row.get('reviewer_notes','')
                })
    out=ROOT/'quote_match_results.csv'
    with out.open('w',newline='',encoding='utf-8') as f:
        cols=['source_filename','repository_path','page_number_1_based','quote_to_verify','article_claim_to_verify','automated_result','page_text_file','reviewer_notes']
        w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(results)
    print(f'Checked {len(results)} entered quotations. Results: {out}')
    print('IMPORTANT: a literal text match is not contextual or legal verification. A no-match may result from OCR, punctuation, page breaks, or a quote spanning pages.')
    return 0
if __name__=='__main__': sys.exit(main())
