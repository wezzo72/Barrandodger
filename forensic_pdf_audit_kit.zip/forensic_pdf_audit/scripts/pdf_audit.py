#!/usr/bin/env python3
"""Download selected PDFs from a public GitHub repository and create a page-level audit pack.

This tool preserves source provenance and extracts text; it does NOT determine truth or
independently authenticate authorship. OCR is used only when a page has little/no extractable text.
"""
from __future__ import annotations
import csv, hashlib, json, os, re, sys, time, urllib.error, urllib.parse, urllib.request
from datetime import datetime, timezone
from pathlib import Path

OWNER = os.getenv('REPO_OWNER', 'wezzo72')
REPO = os.getenv('REPO_NAME', 'Barrandodger')
BRANCH = os.getenv('REPO_BRANCH', 'main')
OUT = Path(os.getenv('AUDIT_OUT', 'forensic-audit-output'))
MANIFEST = Path(os.getenv('AUDIT_MANIFEST', 'docs/target_documents.csv'))
API = f'https://api.github.com/repos/{OWNER}/{REPO}/git/trees/{urllib.parse.quote(BRANCH, safe="")}?recursive=1'
HEADERS = {'User-Agent': 'Barrandodger-Forensic-PDF-Audit/1.0', 'Accept': 'application/vnd.github+json'}

def get(url: str, binary=False):
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read() if binary else r.read().decode('utf-8', 'replace')

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def slug(s: str) -> str:
    return re.sub(r'[^A-Za-z0-9._-]+', '_', s).strip('_')[:140] or 'document'

def load_targets():
    if not MANIFEST.exists():
        raise FileNotFoundError(f'Manifest not found: {MANIFEST}')
    with MANIFEST.open(newline='', encoding='utf-8-sig') as f:
        return [r for r in csv.DictReader(f) if r.get('filename','').strip()]

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT/'documents').mkdir(exist_ok=True)
    (OUT/'pages').mkdir(exist_ok=True)
    (OUT/'logs').mkdir(exist_ok=True)
    run = {'started_utc': datetime.now(timezone.utc).isoformat(), 'repository': f'{OWNER}/{REPO}', 'branch': BRANCH,
           'purpose': 'PDF retrieval, text extraction, OCR fallback, hashes, and page-level review scaffolding; not a truth/authenticity determination.', 'documents': []}
    targets = load_targets()
    print(f'Fetching repository tree for {OWNER}/{REPO}@{BRANCH} ...')
    tree_obj = json.loads(get(API))
    if tree_obj.get('truncated'):
        raise RuntimeError('GitHub API tree response was truncated; cannot claim a complete repository search.')
    tree = [x for x in tree_obj.get('tree',[]) if x.get('type') == 'blob']
    by_name = {}
    for x in tree:
        by_name.setdefault(Path(x['path']).name, []).append(x)
    try:
        import fitz
    except Exception as e:
        raise RuntimeError('PyMuPDF (fitz) unavailable. Install requirements: pymupdf') from e
    try:
        import pytesseract
        from PIL import Image
        OCR_AVAILABLE = True
    except Exception:
        OCR_AVAILABLE = False
    for i, target in enumerate(targets, 1):
        filename = target['filename'].strip()
        expected_path = target.get('repo_path','').strip()
        matches = [x for x in tree if x['path'] == expected_path] if expected_path else by_name.get(filename, [])
        item = {'index': i, 'requested_filename': filename, 'expected_repo_path': expected_path or None,
                'status': None, 'matches': [m['path'] for m in matches], 'pages': [], 'notes': target.get('purpose','').strip()}
        if len(matches) == 0:
            item['status'] = 'NOT_FOUND_IN_REPOSITORY_TREE'
            item['limitations'] = 'No matching filename/path in the GitHub tree. No substitute file was guessed.'
            run['documents'].append(item); print(f'[{i}/{len(targets)}] NOT FOUND: {filename}'); continue
        if len(matches) > 1:
            item['status'] = 'AMBIGUOUS_MULTIPLE_MATCHES'
            item['limitations'] = 'More than one repository path matched this filename. Set repo_path in manifest to select the intended file.'
            run['documents'].append(item); print(f'[{i}/{len(targets)}] AMBIGUOUS: {filename}'); continue
        path = matches[0]['path']
        raw_url = f'https://raw.githubusercontent.com/{OWNER}/{REPO}/{urllib.parse.quote(BRANCH, safe="")}/' + '/'.join(urllib.parse.quote(part, safe='') for part in path.split('/'))
        try:
            data = get(raw_url, binary=True)
            if not data.startswith(b'%PDF'):
                item['status'] = 'DOWNLOAD_NOT_PDF'
                item['limitations'] = 'Downloaded bytes did not begin with the PDF signature.'
                run['documents'].append(item); continue
            stem = f'{i:03d}_{slug(Path(path).name)}'
            pdf_path = OUT/'documents'/f'{stem}.pdf'
            pdf_path.write_bytes(data)
            item.update({'status':'DOWNLOADED', 'repo_path':path, 'source_url':raw_url, 'github_blob_sha':matches[0].get('sha'),
                         'bytes':len(data), 'sha256':sha256(data), 'local_pdf':str(pdf_path)})
            doc = fitz.open(stream=data, filetype='pdf')
            item['page_count'] = len(doc)
            page_lines = []
            quote_template = OUT/'pages'/f'{stem}_page_review.csv'
            with quote_template.open('w', newline='', encoding='utf-8') as cf:
                writer = csv.writer(cf)
                writer.writerow(['source_filename','repository_path','page_number_1_based','extraction_method','page_text_file','quote_to_verify','article_claim_to_verify','verification_status','reviewer_notes'])
                for pno, page in enumerate(doc, 1):
                    txt = page.get_text('text', sort=True) or ''
                    method = 'embedded_text'
                    if len(re.sub(r'\s','',txt)) < 35 and OCR_AVAILABLE:
                        try:
                            pix = page.get_pixmap(matrix=fitz.Matrix(2,2), alpha=False)
                            img = Image.frombytes('RGB', [pix.width,pix.height], pix.samples)
                            txt = pytesseract.image_to_string(img) or txt
                            method = 'ocr_fallback'
                        except Exception as e:
                            method = 'embedded_text_ocr_failed'
                    elif len(re.sub(r'\s','',txt)) < 35:
                        method = 'embedded_text_low_or_empty_ocr_unavailable'
                    text_file = OUT/'pages'/f'{stem}_page_{pno:04d}.txt'
                    text_file.write_text(txt, encoding='utf-8')
                    page_lines.append(f'### Page {pno} — {method}\n\n{text_file.read_text(encoding="utf-8").strip()}\n')
                    writer.writerow([Path(path).name,path,pno,method,str(text_file),'','','NOT_REVIEWED',''])
                    item['pages'].append({'page':pno,'method':method,'characters':len(txt),'text_file':str(text_file),'sha256_text':sha256(txt.encode('utf-8'))})
            (OUT/'pages'/f'{stem}_all_pages.md').write_text('# '+Path(path).name+'\n\n'+'\n\n'.join(page_lines), encoding='utf-8')
            item['page_review_csv'] = str(quote_template)
            item['all_pages_text'] = str(OUT/'pages'/f'{stem}_all_pages.md')
            item['status'] = 'EXTRACTED_PAGE_BY_PAGE'
            doc.close()
            print(f'[{i}/{len(targets)}] OK: {filename} ({item["page_count"]} pages)')
        except Exception as e:
            item['status'] = 'DOWNLOAD_OR_EXTRACTION_ERROR'
            item['error'] = f'{type(e).__name__}: {e}'
            print(f'[{i}/{len(targets)}] ERROR: {filename}: {e}')
        run['documents'].append(item)
        time.sleep(0.15)
    run['finished_utc'] = datetime.now(timezone.utc).isoformat()
    run['summary'] = {
        'requested': len(targets),
        'extracted_page_by_page': sum(x.get('status') == 'EXTRACTED_PAGE_BY_PAGE' for x in run['documents']),
        'not_found': sum(x.get('status') == 'NOT_FOUND_IN_REPOSITORY_TREE' for x in run['documents']),
        'ambiguous': sum(x.get('status') == 'AMBIGUOUS_MULTIPLE_MATCHES' for x in run['documents']),
        'errors': sum(x.get('status') in ('DOWNLOAD_NOT_PDF','DOWNLOAD_OR_EXTRACTION_ERROR') for x in run['documents']),
        'ocr_fallback_available': OCR_AVAILABLE,
        'important': 'Extraction is not quotation verification. Each quote and conclusion still requires human page-level comparison.'
    }
    (OUT/'audit_manifest.json').write_text(json.dumps(run, indent=2, ensure_ascii=False), encoding='utf-8')
    with (OUT/'document_status.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f); w.writerow(['index','requested_filename','status','repo_path','source_url','page_count','sha256','notes_or_error'])
        for d in run['documents']:
            w.writerow([d.get('index'),d.get('requested_filename'),d.get('status'),d.get('repo_path',''),d.get('source_url',''),d.get('page_count',''),d.get('sha256',''),d.get('limitations',d.get('error',''))])
    with (OUT/'README_AUDIT_RESULTS.md').open('w', encoding='utf-8') as f:
        f.write('# PDF audit run results\n\n')
        f.write(f'- Repository: `{OWNER}/{REPO}`\n- Branch: `{BRANCH}`\n- Started (UTC): {run["started_utc"]}\n- Finished (UTC): {run["finished_utc"]}\n\n')
        f.write('## Summary\n\n')
        for k,v in run['summary'].items(): f.write(f'- **{k}**: {v}\n')
        f.write('\n## Limits\n\nThis report records retrieval, file hashes, page counts, extracted text, and OCR fallback status. It does not certify authorship, truth, legal effect, or the accuracy of an article conclusion. Direct quotations must be checked against the corresponding page image. OCR text is a search aid and may contain errors.\n')
        f.write('\n## Document results\n\n')
        for d in run['documents']:
            f.write(f'- **{d.get("requested_filename")}** — `{d.get("status")}`')
            if d.get('repo_path'): f.write(f'; path `{d["repo_path"]}`; pages {d.get("page_count","unknown")}')
            if d.get('limitations'): f.write(f'; {d["limitations"]}')
            if d.get('error'): f.write(f'; {d["error"]}')
            f.write('\n')
    print(json.dumps(run['summary'], indent=2))
    return 0 if run['summary']['errors'] == 0 else 2

if __name__ == '__main__':
    sys.exit(main())
